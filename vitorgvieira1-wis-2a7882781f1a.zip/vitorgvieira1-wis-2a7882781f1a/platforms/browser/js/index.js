function goToSettings(){
    window.location.href = "Settings.html";
}