<?php
	// header("Access-Control-Allow-Origin: *");
    session_start();

    require 'DbConnection.php';

    $pdo = conectaPDO();

    $returnedInsert = createUser($_POST['carro'], $_POST['ano'], $_POST['km'], $_POST['valor'], $pdo);

    if ($returnedInsert == "ok")
        echo json_encode(array ('status' => "created"));
    else
        echo json_encode(array ('status' => "error"));
?>